package com.example.bookshelf.data

data class Book(
    val title: String?,
    val previewLink: String?,
    val imageLink: String?
)