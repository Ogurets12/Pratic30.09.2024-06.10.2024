package com.example.registor

class User(val login: String, val email: String, val pass: String ){

}